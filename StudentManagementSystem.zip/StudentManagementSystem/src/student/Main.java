package student;

import java.util.*;
public class Main {

    public static void main(String[] args) {
        List<studentEntity> students = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nStudent Management System");
            System.out.println("1. Add Student");
            System.out.println("2. View Students");
            System.out.println("3. Update Student");
            System.out.println("4. Delete Student");
            System.out.println("5. Search Students");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                    addStudent(students, scanner);
                    break;
                case 2:
                    viewStudents(students);
                    break;
                case 3:
                    updateStudent(students, scanner);
                    break;
                case 4:
                    deleteStudent(students, scanner);
                    break;
                case 5:
                    searchStudents(students, scanner);
                    break;
                case 6:
                    System.out.println("Exiting the program.");
                    scanner.close();
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
    private static void addStudent(List<studentEntity> students, Scanner scanner) {
        System.out.print("Enter student ID: ");
        int studentID = scanner.nextInt();
        scanner.nextLine(); 
        System.out.print("Enter first name: ");
        String firstName = scanner.nextLine();
        System.out.print("Enter last name: ");
        String lastName = scanner.nextLine();
        System.out.print("Enter email: ");
        String email = scanner.nextLine();
        System.out.print("Enter phone: ");
        String phone = scanner.nextLine();

        studentEntity student = new studentEntity(studentID, firstName, lastName, email, phone);
        students.add(student);

        System.out.println("Student added successfully.");
    }

    private static void viewStudents(List<studentEntity> students) {
        if (students.isEmpty()) {
            System.out.println("No students in the system.");
        } else {
            System.out.println("List of Students:");
            for (studentEntity student : students) {
                System.out.println(student);
            }
        }
    }

    private static void updateStudent(List<studentEntity> students, Scanner scanner) {
        System.out.print("Enter student ID to update: ");
        int studentID = scanner.nextInt();
        scanner.nextLine(); 

        boolean found = false;
        for (studentEntity student : students) {
            if (student.getStudentID() == studentID) {
                System.out.print("Enter new first name: ");
                String firstName = scanner.nextLine();
                System.out.print("Enter new last name: ");
                String lastName = scanner.nextLine();
                System.out.print("Enter new email: ");
                String email = scanner.nextLine();
                System.out.print("Enter new phone: ");
                String phone = scanner.nextLine();

                student.setFirstName(firstName);
                student.setLastName(lastName);
                student.setEmail(email);
                student.setPhone(phone);

                System.out.println("Student updated successfully.");
                found = true;
                break;
            }
        }

        if (!found) {
            System.out.println("Student not found.");
        }
    }

    private static void deleteStudent(List<studentEntity> students, Scanner scanner) {
        System.out.print("Enter student ID to delete: ");
        int studentID = scanner.nextInt();
        scanner.nextLine(); 
        
        Iterator<studentEntity> iterator = students.iterator();
        boolean found = false;
        while (iterator.hasNext()) {
        	studentEntity student = iterator.next();
            if (student.getStudentID() == studentID) {
                iterator.remove();
                System.out.println("Student deleted successfully.");
                found = true;
                break;
            }
        }

        if (!found) {
            System.out.println("Student not found.");
        }
    }

    private static void searchStudents(List<studentEntity> students, Scanner scanner) {
        System.out.print("Enter search keyword (name or ID): ");
        String keyword = scanner.nextLine().toLowerCase();

        boolean found = false;
        for (studentEntity student : students) {
            if (String.valueOf(student.getStudentID()).contains(keyword) ||
                student.getFirstName().toLowerCase().contains(keyword) ||
                student.getLastName().toLowerCase().contains(keyword)) {
                System.out.println(student);
                found = true;
            }
        }

        if (!found) {
            System.out.println("No matching students found.");
        }
    }
}


